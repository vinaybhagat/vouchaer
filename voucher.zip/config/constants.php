<?php 
//file : app/config/constants.php 
return [
	'SITE_NAME' => 'Voucher Pool', 
	'ADMIN_PANEL' => '1', 
    'CLIENT_PANEL' => '2',
	'ADMIN_DISPLAY_PER_PAGE' => '50', 
	'ORDER_AMOUNT' => '100', 
];
