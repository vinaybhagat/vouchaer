<?php 
namespace App\Helpers;
use Auth;
use Session;
use App\Recipient;
use App\SpecialOffer;
use App\Appslog;
class Helper {
	public static function log_insert($action, $user_id , $description,$class = 0){
        $data            = array();
        $data['user_id'] = $user_id;
        $data['action']      = $action;
        $data['description'] = $description;
        if (is_array($data['description']) || is_object($data['description'])) {
            $data['description'] = json_encode($data['description'], JSON_UNESCAPED_UNICODE);
        }
        $data['ip_address'] = $_SERVER['REMOTE_ADDR'];//$this->getClientIp();//Request::getClientIp();
		$data['class'] = $class;
		$data['created_at'] = new \DateTime();
		return Appslog::insert($data);
    }
	
	public function GetName($action, $id){
		$name = '';;
		if($action == 'recipient'){
			$get_detail = Recipient::select('name')->where('id','=',$id)->first();
			if(count($get_detail) != 0){
				$name = $get_detail->name;
			}
		}elseif($action == 'special_offer'){
			$get_detail = SpecialOffer::select('name')->where('id','=',$id)->first();
			if(count($get_detail) != 0){
				$name = $get_detail->name;
			}
		}
		return $name;
    }
}