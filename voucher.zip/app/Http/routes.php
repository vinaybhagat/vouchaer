<?php
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::group(array('prefix' => 'api'), function() { 
	Route::resource('checkvouchercode', 'Api\ApiVoucherController@checkvouchercode');
});
Route::get('/', 'IndexController@index');
Route::post('apply_code', array('as' => 'post.apply_code', 'uses' => 'IndexController@ApplyCode'));
Route::auth();
//admin

Route::group(array('middleware' => 'auth'), function(){ 
	Route::resource('logout', 'Auth\AuthController@logout');
	Route::get('/backend', 'AdminDashboardController@index');
	
	/* Profile */
	Route::get('backend/changepassword', array('as' => 'admin.changepassword', 'uses' => 'AdminProfileController@getReset'));
	Route::post('backend/changepassword', ['as' => 'admin.changepassword','uses' => 'AdminProfileController@postReset']);
	
	/*Recipient */
	Route::get('backend/recipient', array('as' => 'list.recipient', 'uses'=>'RecipientController@index'));
	Route::get('backend/recipient/add', array('as' => 'add.recipient', 'uses'=>'RecipientController@create'));
	Route::post('backend/recipient/add', array('as' => 'add.recipient', 'uses'=>'RecipientController@store'));
	Route::get('backend/recipient/edit/{id}', array('as' => 'edit.recipient', 'uses'=>'RecipientController@edit'));
	Route::post('backend/recipient/edit/{id}', array('as' => 'edit.recipient', 'uses'=>'RecipientController@update'));
	Route::get('backend/recipient/{id}/delete', array('as' => 'delete.recipient', 'uses'=>'RecipientController@destroy'));
	
	/*Special Offer */
	Route::get('backend/specialoffer', array('as' => 'list.specialoffer', 'uses'=>'SpecialOfferController@index'));
	Route::get('backend/specialoffer/add', array('as' => 'add.specialoffer', 'uses'=>'SpecialOfferController@create'));
	Route::post('backend/specialoffer/add', array('as' => 'add.specialoffer', 'uses'=>'SpecialOfferController@store'));
	Route::get('backend/specialoffer/edit/{id}', array('as' => 'edit.specialoffer', 'uses'=>'SpecialOfferController@edit'));
	Route::post('backend/specialoffer/edit/{id}', array('as' => 'edit.specialoffer', 'uses'=>'SpecialOfferController@update'));
	Route::get('backend/specialoffer/{id}/delete', array('as' => 'delete.specialoffer', 'uses'=>'SpecialOfferController@destroy'));
	
	/*Voucher Code */
	Route::get('backend/vouchercode', array('as' => 'list.vouchercode', 'uses'=>'VoucherCodeController@index'));
	Route::get('backend/vouchercode/add', array('as' => 'add.vouchercode', 'uses'=>'VoucherCodeController@create'));
	Route::post('backend/vouchercode/add', array('as' => 'add.vouchercode', 'uses'=>'VoucherCodeController@store'));
	Route::get('backend/vouchercode/edit/{id}', array('as' => 'edit.vouchercode', 'uses'=>'VoucherCodeController@edit'));
	Route::post('backend/vouchercode/edit/{id}', array('as' => 'edit.vouchercode', 'uses'=>'VoucherCodeController@update'));
	Route::get('backend/vouchercode/{id}/delete', array('as' => 'delete.vouchercode', 'uses'=>'VoucherCodeController@destroy'));
});	

