<?php namespace App\Http\Requests;
use Auth;
use App\SpecialOffer;
use App\Http\Requests\Request;
class SpecialOfferRequest extends Request {
	public function authorize(){
		return true;
	}
	public function rules(){
		$name = $this->name;
		if($this->route('id') != ''){
			$check_data = SpecialOffer::where('name','=',$name)->where('id','!=',$this->route('id'))->where('deleted','=','0')->count();
		}else{
			$check_data = SpecialOffer::where('name','=',$name)->where('deleted','=','0')->count();
		}
		if($check_data == 0){
			return [
				'name' => 'required',
				'discount' => 'required|numeric|between:1,100',
			];
		}else{
			return [
				'name' => 'required|unique:special_offers,name,'.$this->route('id'),
				'discount' => 'required|numeric|between:1,100',
			];
			
		}
	}
}
