<?php namespace App\Http\Requests;
use Auth;
use App\VoucherCode;
use App\Http\Requests\Request;
class VoucherCodeRequest extends Request {
	public function authorize(){
		return true;
	}
	public function rules(){
		$voucher_code = $this->voucher_code;
		if($this->route('id') != ''){
			$check_data = VoucherCode::where('voucher_code','=',$voucher_code)->where('id','!=',$this->route('id'))->where('deleted','=','0')->count();
		}else{
			$check_data = VoucherCode::where('voucher_code','=',$voucher_code)->where('deleted','=','0')->count();
		}
		if($check_data == 0){
			return [
				'voucher_code' => 'required',
				'recipient_id' => 'required',
				'special_offer_id' => 'required',
				'expiration_date' => 'required',
			];
		}else{
			return [
				'voucher_code' => 'required|unique:voucher_codes,voucher_code,'.$this->route('id'),
				'recipient_id' => 'required',
				'special_offer_id' => 'required',
				'expiration_date' => 'required',
			];
			
		}
	}
	public function messages(){
		return [
			'recipient_id.required' => 'Select recipient field is required.',
			'special_offer_id.required' => 'Select special offer field is required.',
		];
    }
}
