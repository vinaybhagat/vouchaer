<?php namespace App\Http\Requests;
use Auth;
use App\Recipient;
use App\Http\Requests\Request;
class RecipientRequest extends Request {
	public function authorize(){
		return true;
	}
	public function rules(){
		$email = $this->email;
		if($this->route('id') != ''){
			$check_data = Recipient::where('email','=',$email)->where('id','!=',$this->route('id'))->where('deleted','=','0')->count();
		}else{
			$check_data = Recipient::where('email','=',$email)->where('deleted','=','0')->count();
		}
		if($check_data == 0){
			return [
				'name' => 'required',
				'email' => 'required|email',
			];
		}else{
			return [
				'name' => 'required',
				'email' => 'required|email|unique:recipients,email,'.$this->route('id'),
			];
			
		}
	}
}
