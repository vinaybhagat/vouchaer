<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\SpecialOffer;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\SpecialOfferRequest;
use Illuminate\Http\RedirectResponse;
class SpecialOfferController extends CommonController {
	function __construct() {
        parent::__construct();
		$this->middleware('auth');
	}
	public function index(){
		$specialoffer_list = SpecialOffer::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data = array();
        $return_data['site_title'] = trans('Special Offer') . ' | ' . $this->data['site_title'];
		$return_data['specialoffer_list'] = $specialoffer_list;
		return view('backend/specialoffer/index', array_merge($this->data, $return_data));
	}
	public function create(){
		$return_data = array();
		$return_data['page_condition'] = 'specialoffer_page';
		$return_data['site_title'] = trans('Special Offer') . ' | ' . $this->data['site_title'];
		return view('backend/specialoffer/create', array_merge($this->data, $return_data));
	}
	public function store(SpecialOfferRequest $request){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("special offer created" ,$user_id, $_REQUEST,$class);
		$specialoffer = new specialoffer();
		$specialoffer->name = $request->name;
		$specialoffer->discount = $request->discount;
		$specialoffer->save();
		if ($request->save) {
			return redirect('backend/specialoffer/edit/'.$specialoffer->id)->with('success_message', trans('Special Offer Added Successfully'));
		}else{
			return redirect('backend/specialoffer')->with('success_message', trans('Special Offer Added Successfully'));
		}
	}
	public function edit($id){
		$return_data = array();
		$specialoffer = specialoffer::find($id);
		$return_data['specialoffer'] = $specialoffer;
		$return_data['page_condition'] = 'specialoffer_page';
		$return_data['site_title'] = trans('Special Offer') . ' | ' . $this->data['site_title'];
		return view('backend/specialoffer/create', array_merge($this->data, $return_data));
	}
	public function update(SpecialOfferRequest $request, $id){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("special offer updated" ,$user_id, $_REQUEST,$class);
		$specialoffer = specialoffer::find($id);
		$specialoffer->name = $request->name;
		$specialoffer->discount = $request->discount;
		$specialoffer->save();
		if ($request->save) {
			return redirect('backend/specialoffer/edit/'.$specialoffer->id)->with('success_message', trans('Special Offer Updated Successfully'));
		}else{
			return redirect('backend/specialoffer')->with('success_message', trans('Special Offer Updated Successfully'));
		}
	}
	public function destroy($id){
		$request = array('id'=>$id);
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("special offer deleted" ,$user_id, $request,$class);
		$specialoffer = SpecialOffer::find($id);
		$specialoffer->deleted = 1;
        $specialoffer->save(); 
      	return redirect('backend/specialoffer')->with('success_message', trans('Special Offer Deleted Successfully'));
	}
}
