<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\VoucherCode;
use App\Recipient;
use App\SpecialOffer;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\VoucherCodeRequest;
use Illuminate\Http\RedirectResponse;
class VoucherCodeController extends CommonController {
	function __construct() {
        parent::__construct();
		$this->middleware('auth');
	}
	public function index(){
		$vouchercode_list = vouchercode::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data = array();
        $return_data['site_title'] = trans('Voucher Code') . ' | ' . $this->data['site_title'];
		$return_data['vouchercode_list'] = $vouchercode_list;
		return view('backend/vouchercode/index', array_merge($this->data, $return_data));
	}
	public function create(){
		$return_data = array();
		$recipient_list = Recipient::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data['recipient_list'] = $recipient_list;
		$specialoffer_list = SpecialOffer::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data['specialoffer_list'] = $specialoffer_list;
		$return_data['page_condition'] = 'vouchercode_page';
		$return_data['site_title'] = trans('Voucher Code') . ' | ' . $this->data['site_title'];
		return view('backend/vouchercode/create', array_merge($this->data, $return_data));
	}
	public function store(VoucherCodeRequest $request){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("vouchercode created" ,$user_id, $_REQUEST,$class);
		$sel_expiration_date = '';
		if($request->expiration_date  != ''){
			$select_date_array = explode('/',$request->expiration_date);
			if(count($select_date_array) == 3){
				$sel_expiration_date =  $select_date_array[2].'-'.$select_date_array[1].'-'.$select_date_array[0];
				$sel_expiration_date = date('Y-m-d',strtotime($sel_expiration_date));
				if($sel_expiration_date == '1970-01-01'){
					$sel_expiration_date = '';
				}
			}
		}
		$vouchercode = new vouchercode();
		$vouchercode->voucher_code = $request->voucher_code;
		$vouchercode->recipient_id = $request->recipient_id;
		$vouchercode->special_offer_id = $request->special_offer_id;
		$vouchercode->expiration_date = $sel_expiration_date;
		$vouchercode->used_once = $request->used_once;
		$vouchercode->save();
		if ($request->save) {
			return redirect('backend/vouchercode/edit/'.$vouchercode->id)->with('success_message', trans('Voucher Code Added Successfully'));
		}else{
			return redirect('backend/vouchercode')->with('success_message', trans('Voucher Code Added Successfully'));
		}
	}
	public function edit($id){
		$return_data = array();
		$recipient_list = Recipient::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data['recipient_list'] = $recipient_list;
		$specialoffer_list = SpecialOffer::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data['specialoffer_list'] = $specialoffer_list;
		$vouchercode = VoucherCode::find($id);
		$return_data['vouchercode'] = $vouchercode;
		$return_data['page_condition'] = 'vouchercode_page';
		$return_data['site_title'] = trans('Voucher Code') . ' | ' . $this->data['site_title'];
		return view('backend/vouchercode/create', array_merge($this->data, $return_data));
	}
	public function update(VoucherCodeRequest $request, $id){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("vouchercode updated" ,$user_id, $_REQUEST,$class);
		$sel_expiration_date = '';
		if($request->expiration_date  != ''){
			$select_date_array = explode('/',$request->expiration_date);
			if(count($select_date_array) == 3){
				$sel_expiration_date =  $select_date_array[2].'-'.$select_date_array[1].'-'.$select_date_array[0];
				$sel_expiration_date = date('Y-m-d',strtotime($sel_expiration_date));
				if($sel_expiration_date == '1970-01-01'){
					$sel_expiration_date = '';
				}
			}
		}
		$vouchercode = VoucherCode::find($id);
		$vouchercode->voucher_code = $request->voucher_code;
		$vouchercode->recipient_id = $request->recipient_id;
		$vouchercode->special_offer_id = $request->special_offer_id;
		$vouchercode->expiration_date = $sel_expiration_date;
		$vouchercode->used_once = $request->used_once;
		$vouchercode->save();
		if ($request->save) {
			return redirect('backend/vouchercode/edit/'.$vouchercode->id)->with('success_message', trans('Voucher Code Updated Successfully'));
		}else{
			return redirect('backend/vouchercode')->with('success_message', trans('VoucherCode Updated Successfully'));
		}
	}
	public function destroy($id){
		$request = array('id'=>$id);
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("vouchercode deleted" ,$user_id, $request,$class);
		$vouchercode = VoucherCode::find($id);
		$vouchercode->deleted = 1;
        $vouchercode->save(); 
      	return redirect('backend/vouchercode')->with('success_message', trans('Voucher Code Deleted Successfully'));
	}
}
