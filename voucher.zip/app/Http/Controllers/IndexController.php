<?php namespace App\Http\Controllers;
use View;
use App\Recipient;
use App\VoucherCode;
use App\SpecialOffer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class IndexController extends CommonClientController {
	public function __construct(){
           parent::__construct();
	}
	public function index(){
		$return_data = array(); 
		$home_page = 1;
		$order_amount = config('constants.ORDER_AMOUNT');
		$discount_amount = Session::get('discount_amount');
		if($discount_amount == ''){
			$discount_amount = 0;
		}
		$discount_flage = Session::get('discount_flage');
		$final_amount = $order_amount - $discount_amount; 
		$discount_detail = '';
		$voucher_code = '';
		$email = '';
		$message = '';
		if($discount_flage == 'yes'){
			$discount_detail = Session::get('discount_detail');
			$voucher_code = Session::get('voucher_code');
			$email = Session::get('email');
			$message = '<span style="color:#006600;">SuccessFully Apply.</span>';
		}
		$return_data['order_amount'] = $order_amount;
		$return_data['discount_amount'] = $discount_amount;
		$return_data['voucher_code'] = $voucher_code;
		$return_data['email'] = $email;
		$return_data['message'] = $message;
		$return_data['discount_detail'] = $discount_detail;
		$return_data['final_amount'] = $final_amount;
		$return_data['front_site_title'] = $this->data['front_site_title'];
		$return_data['front_site_name'] = $this->data['front_site_title'];
		$return_data['page_condition'] =  'home_page';
		return view('index',array_merge($this->data, $return_data));
	}
	public function ApplyCode(Request $request){
		Session::put('email', '');
		Session::put('voucher_code', '');
		Session::put('discount_flage', '');
		Session::put('discount_detail', '');
		Session::put('discount_amount', '0');
		$order_amount = config('constants.ORDER_AMOUNT');
		$response = array();
		$email = isset($request->email) ? $request->email : '';;
		$voucher_code = isset($request->voucher_code) ? $request->voucher_code : '';
		if($email == ''){
			$response['status'] = 'error';
			$response['message'] = '<span style="color:#FF0000;">Email field is required.</span>';
		}elseif($voucher_code == ''){
			$response['status'] = 'error';
			$response['message'] = '<span style="color:#FF0000;">Voucher Code field is required.</span>';
		}else{
			$Recipient_Detail 	= Recipient::select('id')->where("email", $email)->where('deleted','=','0')->first();
			if(count($Recipient_Detail) == 0){
				$response['status'] = 'error';
				$response['message'] = '<span style="color:#FF0000;">Email Not Match.</span>';
			}else{
				$recipient_id = $Recipient_Detail->id;
				
				$voucher_code_data = $this->get_voucher_code_amount($recipient_id,$order_amount,$voucher_code);
				$voucher_code_detail = explode('#||#',$voucher_code_data);
				if($voucher_code_detail['0'] == 'yes'){
				
					Session::put('email', $email);
					Session::put('voucher_code', $voucher_code);
					Session::put('discount_flage', 'yes');
					Session::put('discount_detail', $voucher_code_detail['1']);
					Session::put('discount_amount', $voucher_code_detail['3']);
					$response['status'] = 'success';
				}else{
					$response['status'] = 'error';
				}
				$response['message'] = $voucher_code_detail['4'];
			}	
		}	
		
		$discount_amount = Session::get('discount_amount');
		$discount_flage = Session::get('discount_flage');
		$discount_detail = '';
		if($discount_flage == 'yes'){
			$discount_detail = Session::get('discount_detail');
		}
		$final_amount = $order_amount - $discount_amount; 
		$response['order_amount'] = $order_amount;
		$response['discount_amount'] = $discount_amount;
		$response['discount_detail'] = $discount_detail;
		$response['final_amount'] = $final_amount;
		return json_encode($response);	
	}
	public function get_voucher_code_amount($recipient_id,$order_amount,$voucher_code){
	  	$current_date = date('Y-m-d');
		$vouchercode_detail_query = VoucherCode::where("recipient_id", "=", $recipient_id)->where('deleted','=','0');
		$vouchercode_detail_query->where('voucher_code','=',$voucher_code);
		$vouchercode_detail_query->where('expiration_date','>=',$current_date);
		$vouchercode_detail = $vouchercode_detail_query->first();
		$discount_amount = 0.00;
		$discount_detail = '';
		$discount_flage = 'not';
		$message = '<span style="color:#FF0000;">Voucher Code Not Match.</span>';
		if(count($vouchercode_detail) != 0){
			$special_offer_id = $vouchercode_detail->special_offer_id;
			$SpecialOffer_Detail 	= SpecialOffer::select('discount')->where("id", $special_offer_id)->first();
			if(count($SpecialOffer_Detail) != 0){
				$db_discount_value = $SpecialOffer_Detail->discount;
				$discount_amount = $order_amount * $db_discount_value / 100 ;
				$discount_detail = ' [ '.round($db_discount_value). ' % ]'; 
				$discount_flage = 'yes';
				$message = '<span style="color:#006600;">SuccessFully Apply.</span>';
			}else{
				$message = '<span style="color:#FF0000;">Special Offer Not Found.</span>';
			}	
		}
		return $discount_flage.'#||#'.$discount_detail.'#||#'.$order_amount.'#||#'.$discount_amount.'#||#'.$message;
	  }
}

