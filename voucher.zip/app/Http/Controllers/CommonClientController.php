<?php
namespace App\Http\Controllers;
use Route;
use App\Http\Requests;
use View;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Request as SRequest;
use Illuminate\Support\Facades\Session;

class CommonClientController extends Controller {  
	protected $data = array();
	public $login_user_id = '';
    public function __construct(){
		$this->data['front_site_title'] = config('constants.SITE_NAME'); 
		$url = URL::to('/');
        $this->data['site_full_path']=$url; 
        $this->site_full_path = $url;
    }
}
