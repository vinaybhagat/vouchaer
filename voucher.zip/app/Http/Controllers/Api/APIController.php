<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\CommonController;
use App\Http\Requests;
use Illuminate\Http\Request;

class APIController extends CommonController {

    public function __construct(){
        parent::__construct();
    }
    
    public function passwordGenerator(Request $request) {
        $return_data = array();

        $password = $request->json('password');
        
        $return_data['password'] = bcrypt($password);
        return $return_data;
    }
    
    
}
