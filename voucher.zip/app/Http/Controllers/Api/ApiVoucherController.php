<?php 
namespace App\Http\Controllers\Api;   
use App\Http\Requests;
use App\Http\Controllers\Api\APIController;
use Illuminate\Http\Request;
use Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\Guard; 
use Illuminate\Contracts\Auth\PasswordBroker;
use App\Recipient;
use App\VoucherCode;
use App\SpecialOffer;


class ApiVoucherController extends APIController {
	protected $auth;
	protected $passwords; 
	public function __construct(Guard $auth, PasswordBroker $passwords) {
		$this->auth = $auth;
		$this->passwords = $passwords;
		parent::__construct();
		
	}
    public function index() {
        $return_data = array();
        $return_data['test'] =  'test';
        $return_data['message'] = 'test done';
        $return_data['status'] =  1;
        return $return_data;
    }
	//restaurants_detail
    public function checkvouchercode(Request $request){
		Log::info('============');
		Log::info('-------', ['context' => $request]);
		Log::info('-------', ['context' => json_encode($_REQUEST)]);
		//start data pass//////////////////////////////////////
		$email = isset($request->email) ? $request->email : '';;
		$voucher_code = isset($request->voucher_code) ? $request->voucher_code : '';
		$order_amount = config('constants.ORDER_AMOUNT');
		//end data pass//////////////////////////////////////
		//////////////////////////////////////////////////////////
		$response = array();
		if($email == ''){
			$response['status'] = 'error';
			$response['message'] = 'Email field is required.';
		}elseif($voucher_code == ''){
			$response['status'] = 'error';
			$response['message'] = 'Voucher Code field is required.';
		}else{
			$Recipient_Detail 	= Recipient::select('id')->where("email", $email)->where('deleted','=','0')->first();
			if(count($Recipient_Detail) == 0){
				$response['status'] = 'error';
				$response['message'] = 'Email Not Match.';
			}else{
				$recipient_id = $Recipient_Detail->id;
				
				$voucher_code_data = $this->get_voucher_code_amount($recipient_id,$order_amount,$voucher_code);
				$voucher_code_detail = explode('#||#',$voucher_code_data);
				if($voucher_code_detail['0'] == 'yes'){
				
					$response['email'] = $email;
					$response['voucher_code'] = $voucher_code;
					$response['discount_flage'] = 'yes';
					$response['discount_detail'] = $voucher_code_detail['1'];
					$response['discount_amount'] = $voucher_code_detail['3'];
					$response['status'] = 'success';
				}else{
					$response['status'] = 'error';
				}
				$response['message'] = $voucher_code_detail['4'];
			}
		}	
		//////////////////////////////////////////////////////////
		$myrowinfo["data"] = $response;
		//end Data special Product /////////////////////////////////////////////////////////////
		$myrowinfo = json_encode($myrowinfo);
		header('Content-Type: application/json');
		echo $myrowinfo;
	}
	public function get_voucher_code_amount($recipient_id,$order_amount,$voucher_code){
	  	$current_date = date('Y-m-d');
		$vouchercode_detail_query = VoucherCode::where("recipient_id", "=", $recipient_id)->where('deleted','=','0');
		$vouchercode_detail_query->where('voucher_code','=',$voucher_code);
		$vouchercode_detail_query->where('expiration_date','>=',$current_date);
		$vouchercode_detail = $vouchercode_detail_query->first();
		$discount_amount = 0.00;
		$discount_detail = '';
		$discount_flage = 'not';
		$message = 'Voucher Code Not Match.';
		if(count($vouchercode_detail) != 0){
			$special_offer_id = $vouchercode_detail->special_offer_id;
			$SpecialOffer_Detail 	= SpecialOffer::select('discount')->where("id", $special_offer_id)->first();
			if(count($SpecialOffer_Detail) != 0){
				$db_discount_value = $SpecialOffer_Detail->discount;
				$discount_amount = $order_amount * $db_discount_value / 100 ;
				$discount_detail = ' [ '.round($db_discount_value). ' % ]'; 
				$discount_flage = 'yes';
				$message = 'SuccessFully Apply.';
			}else{
				$message = 'Special Offer Not Found.';
			}	
		}
		return $discount_flage.'#||#'.$discount_detail.'#||#'.$order_amount.'#||#'.$discount_amount.'#||#'.$message;
	  }
}
