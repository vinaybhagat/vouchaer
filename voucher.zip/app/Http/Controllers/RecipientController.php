<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\Recipient;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\RecipientRequest;
use Illuminate\Http\RedirectResponse;
class RecipientController extends CommonController {
	function __construct() {
        parent::__construct();
		$this->middleware('auth');
	}
	public function index(){
		$recipient_list = Recipient::where('deleted','=','0')->orderBy('id', 'DESC')->get();
		$return_data = array();
        $return_data['site_title'] = trans('Recipient') . ' | ' . $this->data['site_title'];
		$return_data['recipient_list'] = $recipient_list;
		return view('backend/recipient/index', array_merge($this->data, $return_data));
	}
	public function create(){
		$return_data = array();
		$return_data['page_condition'] = 'recipient_page';
		$return_data['site_title'] = trans('Recipient') . ' | ' . $this->data['site_title'];
		return view('backend/recipient/create', array_merge($this->data, $return_data));
	}
	public function store(RecipientRequest $request){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("recipient created" ,$user_id, $_REQUEST,$class);
		$recipient = new Recipient();
		$recipient->name = $request->name;
		$recipient->email = $request->email;
		$recipient->save();
		if ($request->save) {
			return redirect('backend/recipient/edit/'.$recipient->id)->with('success_message', trans('Recipient Added Successfully'));
		}else{
			return redirect('backend/recipient')->with('success_message', trans('Recipient Added Successfully'));
		}
	}
	public function edit($id){
		$return_data = array();
		$recipient = Recipient::find($id);
		$return_data['recipient'] = $recipient;
		$return_data['page_condition'] = 'recipient_page';
		$return_data['site_title'] = trans('Recipient') . ' | ' . $this->data['site_title'];
		return view('backend/recipient/create', array_merge($this->data, $return_data));
	}
	public function update(RecipientRequest $request, $id){
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("recipient updated" ,$user_id, $_REQUEST,$class);
		$recipient = Recipient::find($id);
		$recipient->name = $request->name;
		$recipient->email = $request->email;
		$recipient->save();
		if ($request->save) {
			return redirect('backend/recipient/edit/'.$recipient->id)->with('success_message', trans('Recipient Updated Successfully'));
		}else{
			return redirect('backend/recipient')->with('success_message', trans('Recipient Updated Successfully'));
		}
	}
	public function destroy($id){
		$request = array('id'=>$id);
		$user_id = $this->login_user_id;
		$class = config('constants.ADMIN_PANEL');
		Helper::log_insert("recipient deleted" ,$user_id, $request,$class);
		$recipient = Recipient::find($id);
		$recipient->deleted = 1;
        $recipient->save(); 
      	return redirect('backend/recipient')->with('success_message', trans('Recipient Deleted Successfully'));
	}
}
