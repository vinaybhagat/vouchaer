<?php
namespace App\Http\Controllers;
use App\Http\Requests;
use Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class AdminDashboardController extends CommonController {
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response 
     */
    public function index() {
		$return_data = array(); 
        $user_id = Auth::id();
        $return_data['site_title'] = trans('common.admin_dashboard_title') . ' | ' . $this->data['site_title'];
        return view('backend/admindashboard', array_merge($this->data, $return_data));
   
   }
}
