<?php
namespace App\Http\Controllers;
use Auth;
use Route;
use App\Appslog;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Request as SRequest;
use Illuminate\Support\Facades\Session;

class CommonController extends Controller { 
	protected $data = array();
	public $login_user_id = '';
    public function __construct(){
		date_default_timezone_set("Asia/Kolkata");
		$this->data['site_title'] = config('constants.SITE_NAME');
		$this->data['site_name'] = config('constants.SITE_NAME');
		$id = Auth::id();
        $user = array();
        if ($id != '') {
            $user = Auth::user();
			if ($user->status == 0){
				Auth::logout();
                return Redirect::to('login')->with('error_message', trans('message.inactive_loginstatus'));
            }
            $this->login_user_id = $id;
            $this->data['login_user_id'] = $this->login_user_id;
            $current_route_name = Route::currentRouteName();
        }
		$this->current_volume_path = config('constants.DEFAULT_VOLUME_PATH');
        $url = URL::to('/');
        $this->data['site_full_path']=$url; 
        $this->site_full_path = $url;
		$this->data['page_condition'] = 'common';
    }
	public function _pre($all_array){
		echo '<pre>';
		print_r($all_array);
		echo '</pre>';
	}
}
