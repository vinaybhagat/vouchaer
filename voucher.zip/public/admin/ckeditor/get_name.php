
<?php

	$nm=$_REQUEST["editor1"];
	$nm1=$_REQUEST["editor2"];
	
	echo $nm."<br>".$nm1;
	

?>

