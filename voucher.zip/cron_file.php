<?php
@session_start();
ini_set("error_reporting", E_ALL);
//live
$DB_Host = "localhost";
$DB_Name="hirespi7_sharetasker";
$DB_Username="hirespi7_shareta";
$DB_Password="sharetasker";
error_reporting(0);
$con=mysql_connect($DB_Host,$DB_Username,$DB_Password) or die(mysql_errno());
$db=mysql_select_db("$DB_Name",$con) or die(mysql_error());

$current_date = date('Y-m-d');
$current_date_minus_date_task_masters = date('Y-m-d', strtotime("-0 days"));
echo $select_task_masters = "select * from task_masters WHERE flage = '0' AND deleted = '0' AND DATE(created_at) <= '".$current_date_minus_date_task_masters."' ORDER BY created_at DESC";
echo '<br>';
$query_task_masters = mysql_query($select_task_masters);
while($fetch_task_masters = mysql_fetch_array($query_task_masters)){
	$fetch_task_masters_id = $fetch_task_masters['id'];
	$fetch_task_masters_id.'=='.$fetch_task_masters['created_at'];
	$update_task_masters = "UPDATE task_masters SET flage = '4' WHERE id = ".$fetch_task_masters_id;
	//mysql_query($update_update_task_masters);
}
echo '<hr>';
//select * from `task_masters` where `flage` = '1' and `deleted` = '0' and `assign_member_id` != '0' and `assign_quote_id` != '0' and date(`assign_datetime`) <= '2017-12-19'

//select * from task_masters WHERE flage = '1' AND deleted = '0' AND assign_member_id != '0' AND assign_quote_id != '0' AND DATE(assign_datetime) <= '2017-12-19' ORDER BY assign_datetime DESC
$current_date_minus_date_task_master_quotes = date('Y-m-d', strtotime("-0 days"));
echo $select_task_masters_quotes = "select * from task_masters WHERE  flage = '1' AND deleted = '0' AND assign_member_id != '0' AND assign_quote_id != '0' AND DATE(assign_datetime) <= '".$current_date_minus_date_task_master_quotes."' ORDER BY assign_datetime DESC";
echo '<br>';
$query_task_masters_quotes = mysql_query($select_task_masters_quotes);
while($fetch_task_masters_quotes = mysql_fetch_array($query_task_masters_quotes)){
	$fetch_task_masters_id = $fetch_task_masters_quotes['id'];
	$fetch_task_quotes_id.'=='.$fetch_task_masters_quotes['assign_datetime'];
	$update_task_masters = "UPDATE task_masters SET flage = '0',assign_member_id = '0',assign_quote_id = '0' WHERE id = ".$fetch_task_masters_id;
	//mysql_query($update_update_task_masters);
	
	$update_task_quotes = "UPDATE task_quotes SET assign_status = '0',assign_accept_status = '0' WHERE task_id = ".$fetch_task_masters_id;
	//mysql_query($update_task_quotes);

}
?>